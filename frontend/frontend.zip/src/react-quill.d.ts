declare module 'react-quill';
